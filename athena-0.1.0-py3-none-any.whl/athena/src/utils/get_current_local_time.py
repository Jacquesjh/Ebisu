import pytz
from datetime import datetime


def get_current_local_time(timezone_name: str) -> datetime:
    newline = "\n"
    if timezone_name not in pytz.all_timezones:
        raise Exception(
            f"""Error: {timezone_name} not valid please choose a valid one, from the pytz lib: \n{newline.join(map(str,pytz.all_timezones))}"""
        )

    local_tz = pytz.timezone(timezone_name)

    def utc_to_local(utc_dt):
        local_dt = utc_dt.replace(tzinfo=pytz.utc).astimezone(local_tz)
        return local_tz.normalize(local_dt)

    return datetime.strptime(
        datetime.strftime(utc_to_local(datetime.utcnow()), "%Y-%m-%d %H:%M:%S"),
        "%Y-%m-%d %H:%M:%S",
    )
