from typing import Optional
from datetime import datetime

from athena.src.domain.exceptions import InvalidDate

BEGINNING_DATE = datetime(2010,1,1) # This is as far as the database goes
                                    # Not sure about the value though


def check_valid_date(date: datetime) -> Optional[bool]:
    if BEGINNING_DATE <= date <= datetime.now():
        return True

    raise InvalidDate(f'Invalid date = {date}')