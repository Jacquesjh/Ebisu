from typing import List, Optional

from athena.src.core.repositories.mongo.i_mongo import IMongoRepository
from athena.src.infrastructure.mongo.infrastructure import MongoDBInfrastructure
from athena.src.domain.exceptions import RepositoryInsertFailure
from athena.src.infrastructure.env_config import config

class MongoDBRepository(IMongoRepository):

    @classmethod
    def instantiate_quote_information(cls):
        return cls(infrastructure = MongoDBInfrastructure(),
                   database=config('QUOTE_INFORMATION_DB'),
                   collection= config('QUOTE_INFORMATION_COLLECTION'))
    
    @classmethod
    def instantiate_weights(cls):
        return cls(infrastructure = MongoDBInfrastructure(),
                   database=config('WEIGHT_DB'),
                   collection= config('WEIGHT_COLLECTION'))
    
    def __init__(self, infrastructure = MongoDBInfrastructure(),
                       database = config('WEIGHT_DB'),
                       collection= config('WEIGHT_COLLECTION')):

        self.infrastructure = infrastructure
        self.database = self.infrastructure.client[database]
        self.collection = self.database[collection]

    def insert_one(self, doc: dict) -> str:
        try:
            result = self.collection.insert_one(doc)
            return result.inserted_id

        except:
            raise RepositoryInsertFailure

    def insert_many(self, doc: List[dict]) -> list:
        try:
            results = self.collection.insert_many(doc)
            return results.inserted_ids

        except:
            raise RepositoryInsertFailure

    def find_one(self, query: dict) -> Optional[dict]:
        try:
            result = self.collection.find_one(query)
            return result
            
        except Exception as e:
            print(e)

    def find_many(self, query: dict) -> Optional[List]:
        try:
            results = self.collection.find(query)
            return list(results)

        except Exception as e:
            print(e)

    def delete_one(self, query: dict) -> int:
        try:
            result = self.collection.delete_one(query)
            if result.deleted_count == 0:
                print(f"No document deleted with query {query}")

            return result.deleted_count

        except Exception as e:
            print(e)

    def delete_many(self, query: List[dict]) -> int:
        """ 
        The raw result (from pymongo itself) doesn't contain the deleted objects.
        """
        try:
            result = self.collection.delete_many(query)
            if result.deleted_count == 0:
                print(f"No document deleted with query {query}")
                
            return result.deleted_count

        except Exception as e:
            print(e)