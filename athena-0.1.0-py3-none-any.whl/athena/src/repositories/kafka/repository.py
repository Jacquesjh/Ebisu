from kafka.admin import NewPartitions
from kafka.producer.kafka import KafkaProducer
from kafka.consumer import KafkaConsumer
from athena.src.domain.entities import RiskProfile
from athena.src.infrastructure.kafka.infrastructure import KafkaConsumerInfrastructure, KafkaProducerInfrastructure

class Consumer(KafkaConsumerInfrastructure):

    @classmethod
    def instance_input(cls, risk_profile: RiskProfile):
        engine = cls.get_connection(f'{risk_profile.name}')
        return cls(engine= engine)

    def __init__(self, engine:KafkaConsumer):
        self.engine = engine

    def get_many(self):
        data = []
        for message in self.engine:
            data.append(message.value)
        return data
        
    def close(self):
        self.engine.unsubscribe()

class Producer(KafkaProducerInfrastructure):

    @staticmethod
    def propagation(wallet_id):
        engine = KafkaProducerInfrastructure.get_connection()
        msg = str({'wallet_id': wallet_id})
        engine.send(topic= 'propagation', value = msg.encode('utf-8') )

    @classmethod
    def instance_output(cls):
        engine = cls.get_connection()
        return cls(engine= engine)

    def __init__(self, engine: KafkaProducer):
        self.engine = engine
        
    def send(self, value):
        msg =  str(value)
        response = self.engine.send(topic = "athena" , value= msg.encode('utf-8'))
        return (response.get(timeout=10))

    def close(self):
        self.engine.close()

if __name__== "__main__":
    Producer.propagation(wallet_id = 'teste')
    producer = Producer.instance_output()
    response = producer.send(value='último teste')
    #print(response)
    #consumer = Consumer.instance_input(risk_profile = RiskProfile.CONSERVADOR)
    #print(consumer.get_many())
    #consumer.close() 