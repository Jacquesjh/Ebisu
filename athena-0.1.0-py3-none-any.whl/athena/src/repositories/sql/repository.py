from sqlalchemy import Table
from sqlalchemy.sql.schema import MetaData
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime
from typing import Optional
import pandas as pd
from athena.src.infrastructure.sql.infrastructure import TimeSeriesInfrastructure
from athena.src.core.repositories.sql.i_sql import ISQLRepository

class SQLRepository(ISQLRepository):

    @classmethod
    def instance(cls, infra = TimeSeriesInfrastructure): 
        session = Session(bind= infra.get_connection())
        if session.is_active:
            return cls(conn= session, table = Table("daily_candles", MetaData(), autoload_with= infra.get_connection()))
        else:
            raise ConnectionRefusedError
          
    def __init__(self, conn, table):
        self.conn = conn
        self.table = table
    
    def get_prices(self):
        return self.conn.query(self.table)
    
    def get_symbol(self):
        return self.conn.query(self.table.columns['symbol'], func.sum(self.table.columns['papers_volume'])).group_by(self.table.columns['symbol']).order_by(func.sum(self.table.columns['papers_volume']).desc())
        
    def close(self):
        return self.conn.close()

if __name__ == "__main__":
    repo = SQLRepository.instance()
    query = repo.get_prices()
    
    query = query.filter(repo.table.columns.date > datetime.fromisoformat('2020-02-05')).filter(repo.table.columns.date < datetime.fromisoformat('2020-02-10'))
    #query =  query.group_by('symbol')
    print(query.all())
    


    #acesso reuters, acesso ao frontend de news