from athena.src.core.repositories.timescale.i_timescale import IAPIRepository
from athena.src.infrastructure.timescaleAPI.infrastructure import TimeScaleInfrastructure

class APIRepository(IAPIRepository):
    #TimeScaleInfrastructure
    @classmethod
    def instance(cls, infra = TimeScaleInfrastructure):
        session = infra.get_connection()
        return cls(session = session)

    def __init__(self, session):
        self.__session = session

    def get_candles(self, params):
        data = self.__session.get("/daily_candles_data?", params = params).json()
        return data['data']['candles']

    def close(self):
        return self.__session.close()    