
"""

    This file contains every exception that will be used throughout the Athena Project.
    
"""

class WeightsDontEqualOne(Exception):
    def __init__(self, message):
        super().__init__(message)

class AssetsListEmpty(Exception):
    def __init__(self, message):
        super().__init__(message)

class WeightsListEmpty(Exception):
    def __init__(self, message):
        super().__init__(message)

class FutureDateInvalid(Exception):
    pass

class InfrastructureConnectionFailure(Exception):
    pass

class RepositoryInsertFailure(Exception):
    pass

class InvalidProfile(Exception):
    pass

class InvalidDate(Exception):
    def __init__(self, message):
        super().__init__(message)

class InsuficcientFunds(Exception):
    def __init__(self, message):
        super().__init__(message)

class InvalidTopic(Exception):
    pass