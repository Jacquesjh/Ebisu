"""

    This library contains every entity and enumerator that will be used in the Athena Project.

"""

import numpy as np
from enum import Enum
from typing import List, Dict
from datetime import datetime
import uuid
from dataclasses import dataclass

from pydantic import BaseModel, validator, Field

from athena.src.domain.exceptions import WeightsDontEqualOne, AssetsListEmpty, WeightsListEmpty
from athena.src.utils.check_valid_date import check_valid_date


class Category(Enum):
    """
        This class enums the category of the Asset.
    """

    FIXED    = "FIX"
    VARIABLE = "VAR"
    

class QuoteType(Enum):
    """
        This class enums the type of the quote of the Asset.
    """

    ETF   = "etf"
    STOCK = "stock"


class AssetInfo(Enum):
    """
        This class contains all the relevant information about an Asset.
    """

    FIXED_INCOME_ETF    = (QuoteType.ETF, Category.FIXED)
    VARIABLE_INCOME_ETF = (QuoteType.ETF, Category.VARIABLE)
    STOCK               = (QuoteType.STOCK, Category.VARIABLE)


    def __init__(self, quote_type: str, category: Category) -> None:
        self.quote_type = quote_type
        self.category   = category


class RiskProfile(Enum):
    """
        The type of profile that this portfolio will follow.
    """
    
    CONSERVADOR = (0.25, 0.75)
    MODERADO    = (0.5, 0.5)
    AGRESSIVO   = (0.75, 0.25)

    
    def __init__(self, variable: float, fixed: float) -> None:
        self.variable_weight = variable
        self.fixed_weight    = fixed


class Asset(BaseModel):
    """
        This class represents the info about a specific Asset.
    """

    ticker: str
    price : float = Field(gt = 0.00)
    shares: int   = Field(gt = 0)
    info  : AssetInfo


    @validator("ticker", pre = True)
    @classmethod
    def ticker_upper_case(cls, value: str) -> str:
        return value.upper()


class Allocation(BaseModel):
    """
        This class represents only the recomendation info about and Asset.
    """

    ticker: str
    weight: float = Field(gt = 0.00, lt = 1.00)
    info  : AssetInfo


    @validator("ticker", pre = True)
    @classmethod
    def ticker_upper_case(cls, value: str) -> str:
        return value.upper()


class Portfolio(BaseModel):
    """
        This class represents an Wallet, with all relevant information.
    """
    
    portfolio_id      : str
    risk_profile      : RiskProfile
    stop_loss         : float = Field(gt = 0.00, lt = 1.00)
    take_profit       : float = Field(gt = 0.00, lt = 1.00)
    initial_date      : datetime
    initial_investment: float = Field(gt = 0.00)
    assets            : Dict[str, int]
    leftover          : float = Field(ge = 0.0)


    @validator("initial_date", pre = True)
    @classmethod
    def valid_date(cls, value: datetime) -> datetime:
        if check_valid_date(value):
            return value


    @validator("assets", pre = True)
    @classmethod
    def assets_not_empty(cls, values: List[Asset]) -> List[Asset]:
        if not values:
            raise AssetsListEmpty(message = f"The list of assets is empty.")
        else:
            return values


class AthenaWeights(BaseModel):
    """
        This class represents the recomendation, i.e., the actual product.
    """

    date   : datetime
    weights: List[Allocation]


    @validator("date", pre = True)
    @classmethod
    def valid_date(cls, value: datetime) -> datetime:
        if check_valid_date(value):
            return value


    @validator("weights", pre = True)
    @classmethod
    def categories_equals_one(cls, values: List[Allocation]) -> List[Allocation]:

        categories = [category for category in Category]

        for category in categories:
            allocs = [alloc.weight for alloc in values if alloc.info.category == category]
            sum_weights = np.round(sum(allocs), 8)
            if sum_weights != 1.00:
               raise WeightsDontEqualOne(message = f"Weights of the {category} category don't equal to one.")

        return values


    @validator("weights", pre = True)
    @classmethod
    def weight_not_empty(cls, values: List[Allocation]) -> List[Allocation]:
        
        if not values:
            raise WeightsListEmpty(message = f"The list of weights is empty.")
        
        else:
            return values


class OrderAction(Enum):
    """
        This class represents the configuration of the Order class.
    """

    BUY  = "buy"
    SELL = "sell"


@dataclass
class Order:
    """
        This class represents an Order, with all relevant information.
    """

    service    : str
    symbol     : str
    args       : dict
    action     : str
    requestHash: str


    def __init__(self, asset: Asset, action: OrderAction, id: str) -> None:
        self.service = "place_order"
        self.symbol  = asset.ticker
        self.args    = {
            "type"    : "order",
            "symbol"  : asset.ticker,
            "action"  : action.value,
            "quantity": asset.shares,
            "tif"     : "DAY",
            "market"  : "bovespa"
        }
        self.action      = "post"
        self.requestHash = f"athena-{id}-{uuid.uuid4()}"