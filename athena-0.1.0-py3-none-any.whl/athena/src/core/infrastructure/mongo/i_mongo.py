from abc import ABC, abstractmethod

from pymongo import MongoClient

class IMongoInfrastructure(ABC):
    @abstractmethod
    def __init__(self) -> None:
        pass

    @abstractmethod
    def get_mongo_client(self) -> MongoClient:
        pass

    @abstractmethod
    def set_connection(self, **kwargs):
        pass
