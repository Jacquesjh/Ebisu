from abc import ABC
class ISQLRepository(ABC):
        #injeção com TimeSeriesInfrastructure
    @classmethod
    def instance(cls): 
        pass
          
    def __init__(self, conn, table):
        pass
    
    def get_prices(self):
        pass
    
    def get_symbol(self):
        pass
        
    def close(self):
        pass