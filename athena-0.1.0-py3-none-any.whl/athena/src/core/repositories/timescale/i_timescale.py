from abc import ABC

class IAPIRepository(ABC):
    @classmethod
    def instance(cls):
        pass

    def __init__(self, session):
        pass

    def get_candles(self, params):
        pass

    def close(self):
        pass    