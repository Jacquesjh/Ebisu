from typing import List, Optional

from abc import ABC, abstractmethod
from pymongo.cursor import Cursor

from athena.src.infrastructure.mongo.infrastructure import MongoDBInfrastructure

class IMongoRepository(ABC):
    @abstractmethod
    def __init__(self, infrastructure: MongoDBInfrastructure,
                        database: str,
                        collection: str) -> None:
        pass

    @abstractmethod
    def insert_one(self, doc: dict) -> str:
        pass

    @abstractmethod
    def insert_many(self, doc: List[dict]) -> list:
        pass

    @abstractmethod
    def find_one(self, query: dict) -> Optional[dict]:
        pass

    @abstractmethod
    def find_many(self, query: List[dict]) -> Optional[Cursor]:
        pass

    @abstractmethod
    def delete_one(self, query: dict) -> int:
        pass

    @abstractmethod
    def delete_many(self, query: List[dict]) -> Optional[list]:
        pass