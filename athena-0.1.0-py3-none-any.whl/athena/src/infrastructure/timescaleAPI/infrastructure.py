import requests
from urllib.parse import urljoin

from athena.src.core.infrastructure.timescale.i_timescale import IInfrastructure
from athena.src.infrastructure.env_config import config

class CandleSession(requests.Session):

    def __init__(self, prefix_url=None, *args, **kwargs):
        super(CandleSession, self).__init__(*args, **kwargs)
        self.prefix_url = prefix_url

    def request(self, method, url, *args, **kwargs):
        url = urljoin(self.prefix_url, url)
        return super(CandleSession, self).request(method, url, *args, **kwargs)

class TimeScaleInfrastructure(IInfrastructure):

    @staticmethod
    def get_connection():
        __host = config("TIMESCALE_HOST")
        __header={"x-thebes-answer": config('HERMES_JWT')}
        session = CandleSession(__host)
        session.headers.update(__header)
        resp = session.get("/docs")
        if resp.status_code == 200:
            return session
        else:
            return resp.raise_for_status()
    
    @classmethod
    def get_singleton_connection(cls, **kwargs):
        pass    