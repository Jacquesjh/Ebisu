from pymongo import MongoClient

from athena.src.core.infrastructure.mongo.i_mongo import IMongoInfrastructure
from athena.src.domain.exceptions import InfrastructureConnectionFailure
from athena.src.infrastructure.env_config.__init__ import config

MONGO_CONNECTION = config('MONGO_CONNECTION')
MONGO_USER = config('MONGO_USER')
MONGO_PASSWORD = config('MONGO_PASSWORD')
MONGO_HOST = config('MONGO_HOST')
MONGO_PORT = config('MONGO_PORT')

class MongoDBInfrastructure(IMongoInfrastructure):
    def __init__(self):
        self.__connection = MONGO_CONNECTION
        self.__user = MONGO_USER
        self.__password = MONGO_PASSWORD
        self.__host = MONGO_HOST
        self.__port = MONGO_PORT
        self.get_mongo_client()

    def get_mongo_client(self) -> MongoClient:
        try:
            self.client: MongoClient = MongoClient(
                f"{self.__connection}://{self.__user}:{self.__password}@{self.__host}:{self.__port}"
            )
            return self.client
            
        except:
            raise InfrastructureConnectionFailure

    def set_connection(self, connection, user, password, host, port):
        self.__connection = connection
        self.__user = user
        self.__password = password
        self.__host = host
        self.__port = port
        return self.get_mongo_client()