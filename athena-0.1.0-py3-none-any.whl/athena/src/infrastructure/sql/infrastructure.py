from athena.src.infrastructure.env_config import config
from athena.src.core.infrastructure.timescale.i_timescale import IInfrastructure
from sqlalchemy import create_engine

class TimeSeriesInfrastructure(IInfrastructure):
    
    @staticmethod
    def get_connection(): 
        engine = create_engine(config('SQL_CONNECTION') +'://'+config('SQL_USER')+':'+config('SQL_PASSWORD')+'@'+config('SQL_HOST')+':'+config('SQL_PORT')+'/'+config('SQL_DATABASE'), echo=False)
        return engine
    
    @classmethod
    def get_singleton_connection(cls):
        pass