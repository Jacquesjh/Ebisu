from kafka import KafkaConsumer, KafkaProducer
from athena.src.domain.exceptions import InvalidTopic
from athena.src.core.infrastructure.kafka.i_kafka import IInfrastructure
from athena.src.infrastructure.env_config import config

POOL_TIMEOUT = 1000
class KafkaConsumerInfrastructure(IInfrastructure): 
    @staticmethod
    def get_connection(topic: str, timeout: int=POOL_TIMEOUT):
        if topic in config('KAFKA_TOPICS'):
            consumer  = KafkaConsumer(
                    topic,
                    bootstrap_servers= f"{config('KAFKA_HOST')}:{config('KAFKA_PORT')}",
                    auto_offset_reset="earliest",
                    consumer_timeout_ms = timeout)
            try:
                return consumer
            except:
                raise ConnectionError
        else:
            raise InvalidTopic

class KafkaProducerInfrastructure(IInfrastructure): 
    @staticmethod
    def get_connection():
        producer  = KafkaProducer(bootstrap_servers= f"{config('KAFKA_HOST')}:{config('KAFKA_PORT')}", retries = 5)
        try:
            return producer
        except:
            raise ConnectionError
    def _available_topic(topic):
        if topic in config('KAFKA_TOPICS'):
            return True
        else:
            raise InvalidTopic