from typing import List, Tuple, Optional
from datetime import datetime, timedelta
from bson.objectid import ObjectId

import numpy as np
import pandas as pd
from pypfopt.hierarchical_portfolio import HRPOpt

from athena.src.services.Data.timescale.data import DataSelection
from athena.src.repositories.mongo.repository import MongoDBRepository
from athena.src.core.repositories.mongo.i_mongo import IMongoRepository
from athena.src.domain.exceptions import InvalidProfile
from athena.src.utils.check_valid_date import check_valid_date

from athena.src.domain.exceptions import InvalidDate
from athena.src.domain.entities import AthenaWeights, Category, Asset, AssetInfo, RiskProfile, Allocation
from athena.src.utils.get_current_local_time import get_current_local_time


class HRP:
    """
    If _momentum_range = 30, this runs by month 
    From the first day of the previous month, until the first day of the given month
    """

    # Attributes

    _weights_rep:    MongoDBRepository = MongoDBRepository.instantiate_weights()
    _quotes_rep:     MongoDBRepository = MongoDBRepository.instantiate_quote_information()
    _data_pool:      DataSelection     = DataSelection.from_database()
    _top_volume:     int =  50
    _top_HRP:        int =  5
    _momentum_range: int =  30

    # Setters

    @classmethod
    def set_data_injection(cls, data_injector: DataSelection) -> None:
        if not issubclass(data_injector.__class__, DataSelection):
            raise TypeError

        cls._data_pool = data_injector
        

    @classmethod
    def set_weights_rep(cls, rep: MongoDBRepository) -> None:
        if not issubclass(rep.__class__, IMongoRepository):
            raise TypeError

        cls._weights_rep = rep

    @classmethod
    def set_quotes_rep(cls, rep: MongoDBRepository) -> None:
        if not issubclass(rep.__class__, IMongoRepository):
            raise TypeError

        cls._quotes_rep = rep

    @classmethod
    def set_top_volume(cls, num_top_volume: int) -> None:
        if type(num_top_volume) != int:
            raise TypeError

        cls._top_volume = num_top_volume

    @classmethod
    def set_top_HRP(cls, num_top_HRP: int) -> None:
        if type(num_top_HRP) != int:
            raise TypeError

        cls._top_HRP = num_top_HRP

    @classmethod
    def set_momentum_range(cls, momentum_range: int) -> None:
        if type(momentum_range) != int:
            raise TypeError
            
        cls._momentum_range = momentum_range


    # Public methods

    @classmethod
    def get_weights(cls, date: datetime) -> dict:
        check_valid_date(date)

        if date.day != 1:
            date = datetime(date.year,date.month,1)

        dummy_id = ObjectId.from_datetime(date)
        return cls._weights_rep.find_one({'_id': dummy_id})


    @classmethod
    def generate_weights(cls, date: datetime, return_weights: bool = False, send_to_mongo: bool = False) -> Optional[AthenaWeights]:
        check_valid_date(date)

        fix_allocs = cls._generate_fix_weights(date)
        var_allocs = cls._generate_var_weights(date)            

        weights = AthenaWeights(date=date, weights=fix_allocs+var_allocs)

        if send_to_mongo:
            cls._send_to_mongo_weights(weights)

        if return_weights:
            return weights


    @classmethod
    def minimum_portfolio(cls, profile: RiskProfile, date: datetime) -> List[Asset]:
        check_valid_date(date)
        if type(profile) != RiskProfile:
            raise InvalidProfile

        var_weights   = profile.variable_weight
        fixed_weights = profile.fixed_weight

        mongo_weights = cls.get_weights(date)

        var_tickers =  [var for var in list(mongo_weights["variable"].keys())]
        fix_tickers =  [fixed for fixed in list(mongo_weights["fixed"].keys())]

        tickers = var_tickers + fix_tickers
        
        weights =  [var_weights*var for var in list(mongo_weights["variable"].values())]
        weights += [fixed_weights*fixed for fixed in list(mongo_weights["fixed"].values())]

        shares = np.array(weights)
        shares = shares/min(shares)
        shares = shares.round()

        assets = []
        for ticker, share in zip(tickers, shares):
            price = cls._get_price(ticker, date)[ticker][0]
            quote_type  = cls._get_quote(ticker)
            if quote_type == 'stock':
                info = AssetInfo.STOCK

            elif quote_type == 'etf':
                if ticker in var_tickers:
                    info = AssetInfo.VARIABLE_INCOME_ETF
                
                else:
                    info = AssetInfo.FIXED_INCOME_ETF

            assets += [Asset(ticker = ticker, price = price, shares = share, info = info)]
        
        return assets


    # Private methods

    @classmethod
    def _month_start_end_dates(cls, date: datetime = datetime(2021,2,1)) -> Tuple[datetime, datetime]:
        end = date
        start = end - timedelta(cls._momentum_range)

        if cls._momentum_range == 30:
            end = date.replace(date.year, date.month, 1)
            start = start.replace(start.year, start.month, 1)

        return start, end


    @classmethod
    def _send_to_mongo_weights(cls, athena_weights: AthenaWeights) -> None:
        date = athena_weights.date
        fixed_weights = {}
        variable_weights = {}
        
        for alloc in athena_weights.weights:
            if alloc.info.category == Category.FIXED:
                fixed_weights[alloc.ticker] = alloc.weight

            elif alloc.info.category == Category.VARIABLE:
                variable_weights[alloc.ticker] = alloc.weight

        weights = {'_id': ObjectId.from_datetime(date),
                   'date': date,
                   'variable': variable_weights,
                   'fixed': fixed_weights,
                   '_created_at': get_current_local_time('America/Sao_Paulo')}

        cls._weights_rep.insert_one(weights)

    
    @classmethod
    def _get_quote(cls, ticker):
        values = cls._quotes_rep.find_one({'symbol': ticker})
        return values['quote_type']


    @classmethod
    def _get_price(cls, ticker, date):
        # Get price. Not prices.

        cls._data_pool.assets = {ticker}
        try:
            data = cls._data_pool.query_ticker_data(date)
            return data

        except InvalidDate:
            end   = date
            start = date - timedelta(days=15)

            print(f"Invalid date = {date}")
            print(f"Trying nearest avaible day since {start}")

            data = cls._data_pool.query_ticker_historical_data(start_date=start, end_date=end)
            last_day = data[-1:]

            if last_day is not None:
                return last_day
            
            raise InvalidDate(f"No avaible data for {date} querying since {start}")


    @classmethod
    def _generate_fix_weights(cls, date: Optional[datetime]) -> List[Allocation]:
        # Equal weights based on the number of stocks

        """
        We don't use the price info for now, so using this only drops performance and increases requests on the database


        cls._data_pool.assets = set(assets_list)
        start_date, end_date = cls._month_start_end_dates(date)
        cls._data_pool.include(AssetInfo.FIXED_INCOME_ETF)
        prices_table = cls._data_pool.query_ticker_historical_data(start_date = start_date, end_date = end_date)
        """

        assets_list = ['FIXA11', 'IRFM11']
        fixed_weight = 1 / len(assets_list)
        fixed_weights = [Allocation(ticker=str(ticker), weight=fixed_weight, info=AssetInfo.FIXED_INCOME_ETF) for ticker in assets_list]

        return fixed_weights


    @classmethod
    def _get_assets_vol(cls, asset_info: AssetInfo, start_date: datetime, end_date: datetime) -> Tuple[set, set]:
        cls._data_pool.assets = set()
        cls._data_pool.include(asset_info, only_fractioned_stocks=True)
        assets_vol = cls._data_pool.query_top_active(quantity=cls._top_volume, start_date = start_date, end_date = end_date)
        assets_set = set(assets_vol['symbol'])

        return assets_set, assets_vol


    @classmethod
    def _get_top_volume(cls, sets_list: List[set]) -> pd.DataFrame:
        vol = pd.concat(sets_list, axis = 0, sort=True)
        vol.reset_index(inplace=True, drop=True)
        vol.sort_values(by='volume', inplace=True, ascending=False)
        
        return vol.iloc[:cls._top_volume]


    @classmethod
    def _get_historical_date(cls, assets: set, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        cls._data_pool.assets = assets
        return cls._data_pool.query_ticker_historical_data(start_date = start_date, end_date = end_date)

        
    @classmethod
    def _generate_var_weights(cls, date: datetime) -> List[Allocation]:
        start_date, end_date = cls._month_start_end_dates(date)

        stocks_set, stocks_vol = cls._get_assets_vol(AssetInfo.STOCK, start_date, end_date)
        etfs_set, etfs_vol = cls._get_assets_vol(AssetInfo.VARIABLE_INCOME_ETF, start_date, end_date)

        vol = cls._get_top_volume([stocks_vol, etfs_vol])

        input_stocks = cls._get_historical_date(set(vol['symbol']), start_date, end_date)

        input_stocks = input_stocks.interpolate()
        input_stocks = input_stocks.dropna(axis = 'columns', how='all')

        returns_m = (1 + input_stocks.pct_change()).cumprod()
        total_return_m = returns_m.iloc[-1].sort_values(ascending = False)

        input_stocks_m = pd.DataFrame(input_stocks[total_return_m.index[0: cls._top_HRP]])
        returns_input_stocks_m = input_stocks_m.pct_change().iloc[1:]

        weights_HRP_pyfopt_m = HRPOpt(returns = returns_input_stocks_m).optimize()

        allocations = []
        for ticker in weights_HRP_pyfopt_m:
            if ticker in stocks_set:
                allocations += [Allocation(ticker=ticker, weight=weights_HRP_pyfopt_m[ticker], info=AssetInfo.STOCK)]

            elif ticker in etfs_set:
                allocations += [Allocation(ticker=ticker, weight=weights_HRP_pyfopt_m[ticker], info=AssetInfo.VARIABLE_INCOME_ETF)]

        return allocations
