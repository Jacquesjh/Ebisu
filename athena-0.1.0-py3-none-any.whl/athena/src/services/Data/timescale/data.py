from typing import Optional
from datetime import datetime, timedelta

import pandas as pd
from sqlalchemy import desc
import holidays

from athena.src.repositories.sql.repository import SQLRepository
from athena.src.core.repositories.sql.i_sql import ISQLRepository
from athena.src.repositories.timescale.repository import APIRepository
from athena.src.core.repositories.timescale.i_timescale import IAPIRepository
from athena.src.repositories.mongo.repository import MongoDBRepository
from athena.src.domain.entities import AssetInfo, QuoteType
from athena.src.domain.exceptions import FutureDateInvalid, InvalidDate
class DataSelection:
   
    @classmethod
    def from_API(cls):
        return cls(conn = APIRepository.instance())

    @classmethod
    def from_database(cls):
        return cls(conn = SQLRepository.instance())

    def __init__(self, conn) :
        self.assets = set()
        self.conn = conn

    #to_do max_price, limit asset selection to a certain treshhold price
    def include(self, asset_info:AssetInfo, only_fractioned_stocks:bool=True):
        raw_data = MongoDBRepository.instantiate_quote_information().find_many({'quote_type':asset_info.quote_type.value})
        if asset_info.quote_type == QuoteType.STOCK and only_fractioned_stocks == True:
            data = [ticker['symbol'] for ticker in raw_data if ticker['symbol'].endswith("F")]
        elif asset_info.quote_type == QuoteType.ETF:
            raw_data = MongoDBRepository.instantiate_quote_information().find_many({'etf_type':asset_info.category.value})
            data = [ticker['symbol'] for ticker in raw_data]
        else:
            data = [ticker['symbol'] for ticker in raw_data]
        for item in data:
            self.assets.add(item)
        return self

    def blacklist_by_criteria(self, date: datetime, limit, criteria: str='close'):

        if isinstance(date, str):
            date = datetime.fromisoformat(date)
        if date > datetime.today():
            raise FutureDateInvalid

        if issubclass(type(self.conn), ISQLRepository):
            query = self.conn.get_prices()
            if len(self.assets) > 0:
                query = query.filter(self.conn.table.columns.symbol.in_(self.assets))
            if date is not None:
                query = query.filter(self.conn.table.columns.date == date)
            if criteria in self.conn.table.columns.keys():
                query = query.filter(self.conn.table.columns[criteria] <= limit)
            try:
                frame = pd.DataFrame(query.all(), columns=self.conn.table.columns.keys())   
            except:
                    if date.weekday() > 5:
                        msg = 'Chosen date is a weekend'
                    elif date in holidays.Brazil():
                        msg = 'Chosen date is a holiday'
                    else:
                        msg = f'Gap in the database, there is no data available for {date}\nAssets: {self.assets}'
                    raise InvalidDate(msg)
            finally:
                query = query.filter(self.conn.table.columns.date <= date).filter(self.conn.table.columns.date > date - timedelta(15)).order_by(desc(self.conn.table.columns.date))
                frame = pd.DataFrame(query.all(), columns=self.conn.table.columns.keys())
                for asset in frame['symbol'].to_list():
                    self.assets.remove(asset)
                return self

        elif issubclass(type(self.conn), IAPIRepository):
            raise NotImplementedError
        #    frame = pd.DataFrame(columns=list(self.assets))
        #    for ticker in self.assets:
        #        list_of_prices = self.conn.get_candles(params={'symbol': ticker, 'from_date':date, 'to_date': date})
        #        if list_of_prices:
        #            frame[ticker] = pd.Series(data={price['time']:price['close'] for price in list_of_prices})
        #    return frame
        #
        else:
            raise NotImplementedError


    def query_top_active(self, quantity: int, start_date: Optional[datetime]= None, end_date: Optional[datetime]= None):
        if end_date is not None and start_date is not None:
            if end_date<start_date:
                raise FutureDateInvalid
        if issubclass(type(self.conn), ISQLRepository):
            query = self.conn.get_symbol()
            if len(self.assets) > 0:
                query = query.filter(self.conn.table.columns.symbol.in_(self.assets))
            if start_date is not None:
                query = query.filter(self.conn.table.columns.date >= start_date)
            if end_date is not None:
                query = query.filter(self.conn.table.columns.date <= end_date)
            try:
                return pd.DataFrame().from_records(query.limit(quantity).all(), columns=['symbol', 'volume'])
            except:
                raise KeyError

        elif issubclass(type(self.conn), IAPIRepository):
            raise NotImplementedError

        else:
            raise NotImplementedError

    
    def query_ticker_historical_data(self,start_date: Optional[datetime]= None, end_date: Optional[datetime]= None, data_type: str = 'close'):
        if end_date is not None and start_date is not None:
                if end_date<start_date:
                    raise FutureDateInvalid
        if issubclass(type(self.conn), ISQLRepository):
            query = self.conn.get_prices() 
            if len(self.assets) >0:
                query = query.filter(self.conn.table.columns.symbol.in_(self.assets))
            if start_date is not None:
                query = query.filter(self.conn.table.columns.date >= start_date)
            if end_date is not None:
                query = query.filter(self.conn.table.columns.date <= end_date)

            if data_type in self.conn.table.columns.keys():
                frame = pd.DataFrame(query.all(), columns=self.conn.table.columns.keys()).pivot(values=data_type, index='date', columns='symbol')   
                return frame

            else: 
                raise NotImplementedError

        elif issubclass(type(self.conn), IAPIRepository):
            frame = pd.DataFrame(columns = list(self.assets))
            for ticker in self.assets:
                list_of_prices = self.conn.get_candles(params={'symbol': ticker, 'from_date':start_date, 'to_date': end_date})
                if data_type not in list_of_prices.keys():
                    raise NotImplementedError('The data you are looking for is not in our database')
                if list_of_prices:
                    frame[ticker] = pd.Series(data={price['time']:price[data_type] for price in list_of_prices})
            return frame 

        else:
            raise NotImplementedError
    
    def query_ticker_data(self, date: datetime, data_type: str = 'close'):
        if isinstance(date, str):
            date = datetime.fromisoformat(date)
        if date > datetime.today():
            raise FutureDateInvalid

        if issubclass(type(self.conn), ISQLRepository):
            query = self.conn.get_prices()
            if len(self.assets) > 0:
                query = query.filter(self.conn.table.columns.symbol.in_(self.assets))
            if date is not None:
                query_date = query.filter(self.conn.table.columns.date == date)
            if data_type in self.conn.table.columns.keys():
                try: 
                    frame = pd.DataFrame(query_date.all(), columns=self.conn.table.columns.keys())
                except:
                    if date.weekday() > 5:
                        msg = 'Chosen date is a weekend'
                    elif date in holidays.Brazil():
                        msg = 'Chosen date is a holiday'
                    else:
                        msg = f'Gap in the database, there is no data available for {date}\nAssets: {self.assets}'
                    raise InvalidDate(msg)
                finally:
                    query = query.filter(self.conn.table.columns.date <= date).filter(self.conn.table.columns.date > date - timedelta(15)).order_by(desc(self.conn.table.columns.date))
                    frame = pd.DataFrame(query.all(), columns=self.conn.table.columns.keys())
                    frame = frame.pivot(values=data_type, index='date', columns='symbol')
                    return frame.iloc[-1].to_frame(name=data_type)

        elif issubclass(type(self.conn), IAPIRepository):
            #frame = pd.DataFrame(columns=list(self.assets))
            #for ticker in self.assets:
            #    list_of_prices = self.conn.get_candles(params={'symbol': ticker, 'from_date':date, 'to_date': date})
            #    if data_type not in list_of_prices.keys():
            #        raise NotImplementedError('The data you are looking for is not in our database')
            #    if list_of_prices:
            #        frame[ticker] = pd.Series(data={price['time']:price[data_type] for price in list_of_prices})
            #return frame
            raise NotImplementedError
        else:
            raise NotImplementedError    
            
            
            
            
            
if __name__ == "__main__":
    pool = DataSelection.from_database()
    pool.include(AssetInfo.STOCK)
    print(pool.assets.__len__())

    pool.blacklist_by_criteria(date ='2021-10-08', criteria= 'close', limit=40.00)
    pool.blacklist_by_criteria(date ='2021-10-09', criteria= 'close',  limit=40.00)
    print(pool.assets.__len__())
