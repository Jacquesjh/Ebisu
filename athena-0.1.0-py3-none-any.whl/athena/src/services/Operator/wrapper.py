from typing import List
from athena.src.repositories.kafka.repository import Producer
from athena.src.domain.entities import Order, RiskProfile
from athena.src.domain.exceptions import InvalidProfile

#from tests.stub_classes.stub_order import Stub_Order
#from tests.stub_classes.stub_portfolio import Stub_Portfolio

def send_to_kafka(func):
    
    def KafkaWrapper(wallet_id:str, orders_list:List[Order]):
        f = func()
        queue = Producer.instance_output()
        queue.send(value = f)
        return f

    
    return KafkaWrapper
#class Test:
#    def __init__(self, profile: RiskProfile) :
#        self.profile = profile
#
#    def daily():
#        return Stub_Order()