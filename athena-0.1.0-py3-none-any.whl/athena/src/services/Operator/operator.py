
from typing import Dict, Optional, Any, List
from datetime import datetime
import secrets

import numpy as np

from athena.src.domain.entities import Asset, RiskProfile, OrderAction, Order, Portfolio
from athena.src.domain.exceptions import AssetsListEmpty, InsuficcientFunds
from athena.src.services.WeightsGeneration.hrp import HRP
from athena.src.utils.check_valid_date import check_valid_date
from athena.src.services.Operator.wrapper import send_to_kafka

class Operator:

    profile      : RiskProfile
    date         : datetime
    min_price    : float
    min_portfolio: List[Asset]


    def __init__(self, profile: RiskProfile, date: datetime = datetime.today()):

        self.profile       = profile
        self.min_portfolio = HRP.minimum_portfolio(profile, date)

        if check_valid_date(date):
            self.date = date

        if len(self.min_portfolio) == 0:
            raise AssetsListEmpty(message = f"The min portfolio list is empty.")

        self.min_price = sum([asset.price*asset.shares for asset in self.min_portfolio])


    def rebalance(self, portfolio: Portfolio, previous_min_portfolio: List[Asset]) -> List[Order]:

        orders = self._rebalance_portfolio(portfolio, previous_min_portfolio)
        return orders


    def daily(self, portfolio: Portfolio) -> List[Order]:

        orders = self._check_triggers(portfolio)
        return orders


    def new_portfolio(self, investment: float, portfolio_id: str) -> List[Order]:

        orders = self._generate_portfolio(investment, portfolio_id)
        return orders


    def _generate_portfolio(self, investment: float, portfolio_id: str) -> List[Order]:
        """
            Num novo investimento, o portfolio_id é criado pelo Back ou por nos?
        """
        min_price     = self.min_price
        min_portfolio = self.min_portfolio

        if investment < min_price:
            raise InsuficcientFunds(message = f"{investment} is not enough to buy one unity of the min portfolio, which costs {min_price}")

        multiplier = np.floor(investment/min_price)
        orders     = []

        for asset in min_portfolio:
            ticker = asset.ticker
            price  = asset.price
            shares = multiplier*asset.shares
            info   = asset.info

            order_id  = f"{portfolio_id}-{secrets.token_hex(4)}"
            new_asset = Asset(ticker = ticker, price = price, shares = shares, info = info)
            orders.append(Order(asset = new_asset, action = OrderAction.BUY, id = order_id))

        return orders
    
    
    def _rebalance_portfolio(self, portfolio: Portfolio, previous_min_portfolio: List[Asset]) -> List[Order]:
        
        min_price     = self.min_price
        min_portfolio = self.min_portfolio
        
        assets    = self._get_assets(portfolio, previous_min_portfolio)
        investido = portfolio.leftover

        current_shares = dict()
        prices         = dict()
        infos          = dict()

        for asset in assets:
            investido = investido + asset.price*asset.shares

            current_shares[asset.ticker] = asset.shares
            prices[asset.ticker] = asset.price
            infos[asset.ticker]  = asset.info

        multiplier = np.floor(investido/min_price)
        new_shares = dict()

        for asset in min_portfolio:
            new_shares[asset.ticker] = asset.shares

            if asset.ticker not in current_shares:
                prices[asset.ticker] = asset.price
                infos[asset.ticker]  = asset.info

        tickers     = list(np.unique(list(current_shares.keys()) + list(new_shares)))
        tickers.sort()
        buy_orders  = []
        sell_orders = []

        for ticker in tickers:
            if ticker not in new_shares:
                amount = -current_shares[ticker]

            elif ticker not in current_shares:
                amount = multiplier*new_shares[ticker]

            else:
                amount = multiplier*new_shares[ticker] - current_shares[ticker]

            if amount == 0:
                pass

            else:
                asset    = Asset(ticker = ticker, price = prices[ticker], shares = abs(amount), info = infos[ticker])
                order_id = f"{portfolio.portfolio_id}-{secrets.token_hex(4)}"

                if amount < 0:
                    order = Order(asset = asset, action = OrderAction.SELL, id = order_id)
                    sell_orders.append(order)

                else:
                    order = Order(asset = asset, action = OrderAction.BUY, id = order_id)
                    buy_orders.append(order)
        
        orders = sell_orders + buy_orders
        return orders


    def _check_triggers(self, portfolio: Portfolio) -> List[Order]:
        
        min_portfolio = self.min_portfolio
        
        assets     = self._get_assets(portfolio, min_portfolio)
        investment = sum([asset.price*asset.shares for asset in assets])
        orders     = []

        if investment >= (portfolio.initial_investment - portfolio.leftover)*(1 + portfolio.take_profit):
            for asset in assets:
                order_id = f"{portfolio.portfolio_id}-{secrets.token_hex(4)}"
                order = Order(asset = asset, action = OrderAction.SELL, id = order_id)
                orders.append(order)

        if investment <= (portfolio.initial_investment - portfolio.leftover)*(1 - portfolio.stop_loss):
            for asset in assets:
                order_id = f"{portfolio.portfolio_id}-{secrets.token_hex(4)}"
                order = Order(asset = asset, action = OrderAction.SELL, id = order_id)
                orders.append(order)

        return orders


    def _get_assets(self, portfolio: Portfolio, rec_portfolio: List[Asset]) -> List[Asset]:
        
        assets = []
        
        for asset in rec_portfolio:
            ticker = asset.ticker
            price  = asset.price
            shares = portfolio.assets[ticker]
            info   = asset.info

            assets.append(Asset(ticker = ticker, price = price, shares = shares, info = info))

        return assets