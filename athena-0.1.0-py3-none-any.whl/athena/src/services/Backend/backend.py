
from typing import Dict, Any, List

from athena.src.domain.entities import RiskProfile, Order

from athena.src.repositories.mongo.repository import MongoDBRepository

class Backend:

    @classmethod
    def get_user_info(cls, id) -> Dict[str, Any]:
        mongo = MongoDBRepository(collection = "fake-users")

        pass

    @classmethod
    def get_active_user(cls, profile: RiskProfile) -> List[Any]:
        mongo = MongoDBRepository(collection = "fake-users")

        pass

    @staticmethod
    def send_orders(order: Order) -> None:
        mongo = MongoDBRepository()

        pass